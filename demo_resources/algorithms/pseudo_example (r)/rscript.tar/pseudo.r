# Sleep for 3 seconds
Sys.sleep(3)

# Function to write numbers to a CSV file
write_numbers_to_csv <- function(x, y, alpha, resultID) {
  # Data to write to the CSV file
  data <- data.frame(
    Parameter = c("x", "y", "alpha"),
    Value = c(x, y, alpha)
  )


  filePath <- paste("results/", resultID, ".csv", sep = "")

  cat("Created directory...\n")

  # Write data to a new CSV file
  write.csv(data, file = filePath, row.names = FALSE)

  cat("Set up Csv Writer...\n")
  cat("Wrote headers...\n")
  cat("Finished 1...\n")
}

# Command-line arguments
args <- commandArgs(trailingOnly = TRUE)
csvFile <- args[1]
x <- args[2]
y <- args[3]
alpha <- args[4]
resultID <- args[5]

cat("Successfully read parameters\n")

# Write numbers to a CSV file
write_numbers_to_csv(x, y, alpha, resultID)

cat("finished2...\n")
